<?php get_header(); ?>

<body>
    <header>
        <h1>Doctor Consult</h1>
        <h2>Book your appointment easily</h2>
    </header>

    <main>
        <section>
            <h3>Our Services</h3>
            <ul>
                <li>General Consultation</li>
                <li>Specialist Consultation</li>
                <li>Telemedicine</li>
            </ul>
        </section>

        <section>
            <h3>Contact</h3>
            <p>Email: contact@doctorconsult.com</p>
            <p>Phone: +91 1234567890</p>
        </section>
    </main>

    <footer>
        <p>&copy; 2025 Doctor Consult. All rights reserved.</p>
    </footer>
</body>
</html>

<?php get_footer(); ?>